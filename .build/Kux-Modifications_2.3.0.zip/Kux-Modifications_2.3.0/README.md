- offshore-pump can be used as well pump
- underground length for belts and pipes is maximized
- robots are faster and less power consuming
- Krastorio crash-site generator has 20MW ([Krastorio2](https://mods.factorio.com/mod/Krastorio2))
- Cheeper advanced combinator ([Advanced Combinator](https://mods.factorio.com/mod/advanced-combinator)
- increased bulk rail unloader inventory size ([Bulk Rail Loader](https://mods.factorio.com/mod/railloader))
- Items for a faster start
    - 50 large power grid poles, 50 large power line poles ([Kuxynator's Power Poles](https://mods.factorio.com/mod/Kux-Power-Poles))
    - 20 mining drones, 4 mining depots ([Mining Drones](https://mods.factorio.com/mod/Mining_Drones))
    - 16 Loader  ([Deadlock Stacking]([https://mods.factorio.com/mod/deadlock_stacked_recipes))
    - 100 logistic bots
    - 1 flying roboport ([FlyingRoboport](https://mods.factorio.com/mod/FlyingRoboport))

All mods are optional and must be activated manually.