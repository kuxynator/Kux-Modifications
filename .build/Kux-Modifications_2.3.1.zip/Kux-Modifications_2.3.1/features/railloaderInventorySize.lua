if mods["railloader"] then
	local railunloaderChestEntity = data.raw["container"]["railunloader-chest"]
	railunloaderChestEntity.inventory_size = 500 --320
end